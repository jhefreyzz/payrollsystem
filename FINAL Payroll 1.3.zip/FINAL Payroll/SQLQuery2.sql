-------DATABASE CREATION-------
create database Payroll_System
use payroll_system

-------START OF TABLE DECLARATIONS-------

---table Employee---
create table tbl_Emp
(
emp_id int primary key identity(1,1),
emp_Name varchar(50) not null,
gender varchar(20) not null,
status varchar(20) not null,
address varchar(100) not null,
dept varchar(50) not null,
position varchar(50) not null,
emp_stat varchar(50) not null,
basic_rate decimal(18,2) not null,
date_employed varchar(50) not null,
emp_photo varbinary(max) not null
)

---table Payroll---
create table tbl_payroll
(
Trans_ID int primary key identity(1,1),
emp_id int not null foreign key references tbl_Emp(emp_id) on delete cascade,
emp_name varchar(50) not null,
monthly_rate decimal(18,2) not null,
dDate datetime not null,
xBonus decimal(18,2) not null,
xOT  decimal(18,2) not null,
SSS  decimal(18,2) not null,
PH  decimal(18,2) not null,
InTax  decimal(18,2) not null,
Others  decimal(18,2) not null,
absences  decimal(18,2) not null,
advances decimal(18,2) not null,
tad  decimal(18,2) not null,
td decimal(18,2) not null,
netpay decimal(18,2) not null,
)

---table User---
drop table tbl_user
create table tbl_User
(
id int primary key identity(1,1),
username varchar(50) not null,
passwords varchar(50) not null
)

---table TimeLog---
drop table tbl_TimeLog
create table tbl_TimeLog
(
log_id int primary key identity(1,1),
emp_name varchar(50) not null,
date_log datetime not null,
in_am varchar(50),
out_am varchar(50),
total_am varchar(50),
in_pm varchar(50),
out_pm varchar(50),
total_pm varchar(50),
grand_total varchar(50),
id int not null foreign key references tbl_Emp(emp_id) on delete cascade
)

-------END OF TABLE DECLARATION-------


-------START OF STORED PROCEDURES-------

-----Stored Procedure for Table User-----
---Add Admin---
create procedure Add_Admin

@username varchar(50),
@password varchar(50)

as

insert into tbl_user (username,passwords) values(@username,@password)

-----Stored Procedures for Table Employee-----
---View Employee---
create procedure View_Employee

as

select * from tbl_Emp

---Add Employee---
create procedure Add_Employee

@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50),
@emp_photo varbinary(max)

as

insert into tbl_emp (emp_name,gender,status,address,dept,position,emp_stat,basic_rate,date_employed,emp_photo) values (@emp_name,@gender,@status,@address,@dept,@position,@emp_stat,@basic_rate,@date_employed,@emp_photo)

---Delete Employee---
create procedure Del_Employee

@id int

as
delete from tbl_Emp
where emp_id = @id

---Update Employee---
create procedure Upd_Employee

@emp_id int,
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50)

as

update tbl_Emp
set emp_name =@emp_name,gender=@gender,status=@status,address = @address, dept =@dept,position=@position,emp_stat = @emp_stat,basic_rate=@basic_rate,date_employed = @date_employed
where emp_id = @emp_id

---Update Photo---
create procedure Upd_Photo

@emp_photo varbinary(max),
@id int

as
update tbl_Emp
set emp_photo = @emp_photo
where emp_id = @id


-----Stored Procedures for Table TimeLog-----
---View Timelog---
create procedure View_TimeLog
as
select * from tbl_timelog

---View TimeLog by Name---
create procedure View_TimeLog_Name

@emp_name varchar(50)
as

select * from tbl_Timelog
where emp_name like '%' + @emp_name

---View TimeLog by Date---
drop procedure View_TimeLog_date
create procedure View_TimeLog_Date
@startdate datetime,
@enddate datetime

as	

select * from tbl_Timelog
where date_log between @startdate and @enddate

---Insert TimeLog AM---
create procedure Insert_AM

@emp_name varchar(50),
@in_am varchar(50),
@id int,
@date_log datetime
as
insert into tbl_timelog (emp_name,in_am,date_log,id) values (@emp_name,@in_am,@date_log,@id)

---Update TimeLog OUT AM---
create procedure  Insert_AM_Out
@out_am varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_am = @out_am
where id = @id and date_log = @date

---Update TimeLog TOTAL AM---
drop procedure insert_am_total
create procedure  Insert_AM_TOTAL
@id int,
@date datetime
as
update tbl_timelog
set total_am =  CONVERT(VARCHAR(8), (CAST(out_am AS DATETIME) - CAST(in_am AS DATETIME)), 108)
where id = @id and date_log = @date

select 
LEFT(DATEADD(SECOND, - DATEDIFF(SECOND, convert(time,out_am), convert(time,in_am)), convert(time,'0:0')),8) 
from tbl_timelog;

delete from tbl_timelog
select * from tbl_timelog

select casout_am-in_am from tbl_timelog
select substring((cast(out_am as datetime) - cast(in_am as datetime)),15,20) from tbl_Timelog
select datediff(millisecond,in_am,out_am) from tbl_timelog
select CONVERT(VARCHAR(50)cast(out_am as datetime) - cast(in_am as datetime)) as result from tbl_timelog


SELECT DATEDIFF(MINUTE,cast( out_am as datetime),cast( in_am as datetime) + 1) AS MinuteDiff from tbl_timelog
SELECT DATEDIFF(SECOND, cast( out_am as datetime),cast( in_am as datetime)+ 1) AS SecondDiff from tbl_timelog
SELECT DATEDIFF(WEEK, cast( out_am as datetime),cast( in_am as datetime) + 1) AS WeekDiff from tbl_timelog
SELECT DATEDIFF(HOUR,cast( out_am as datetime),cast( in_am as datetime) + 1) AS HourDiff from tbl_timelog

select cast(cast(out_am as datetime) - cast(in_am as datetime) as time)
from tbl_timelog;

select * from tbl_timelog
SELECT CONVERT(VARCHAR(8), (CAST(out_am AS DATETIME) - CAST(in_am AS DATETIME)), 108) FROM tbl_timelog



---Update TimeLog IN PM---
create procedure Insert_PM_IN
@in_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set in_pm = @in_pm
where id = @id and date_log = @date

---Update TimeLog OUT PM---
create procedure Insert_PM_Out
@out_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_pm = @out_pm
where id = @id and date_log = @date


---Update TimeLog Total AM---
drop proc total_pm
create procedure Total_PM
@id int,
@date datetime

as
update tbl_Timelog
set total_pm = substring(cast(cast(out_pm as datetime) as varchar(50)),15,20) - substring( cast (in_pm as datetime)),15,20) from tbl_timelog
where id = @id and date_log = @date

select   substring((cast(out_pm as datetime) -   cast(out_am as datetime)),12,20)  from tbl_timelog


select * from tbl_timelog
---Update TimeLog Total PM---
create procedure testing_total

as

declare @s varchar(50)
select @s = cast(out_am as datetime) - cast(in_am as datetime) from tbl_timelog
return @s

---CHECK IF DATA EXISTS BASED on ID and Current Date---
---Insert AM if no data exists---
create procedure Check_AM

@id int,
@date datetime

as

declare @checkdate int

select @checkdate = count(*) from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for In AM exists---
create procedure Check_AM_Out
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(out_am) from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for OUT AM and IN AM exists---
create procedure Check_Total_AM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(total_am)from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for OUT AM exists---
create procedure Check_PM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(in_pm) from tbl_timelog
where id = @id and date_log = @date
return @checkdate


---If TimeLog for In AM exists---
create procedure Check_PM_Out
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(out_pm) from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for OUT PM and IN PM exists---
create procedure Check_Total_PM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(total_pm)from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for TOTAL_PM exists---
create procedure Check_Total_PM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(out_pm)from tbl_timelog
where id = @id and date_log = @date
return @checkdate






-----Stored Procedures for Table Payroll-----
---Insert Payroll---
create procedure Add_Payroll
@emp_id int,
@emp_name varchar(50) ,
@monthly_rate decimal(18,2) ,
@dDate datetime ,
@xBonus decimal(18,2),
@xOT  decimal(18,2),
@SSS  decimal(18,2),
@PH  decimal(18,2) ,
@InTax  decimal(18,2),
@Others  decimal(18,2),
@absences  decimal(18,2),
@advances decimal(18,2),
@tad  decimal(18,2),
@td decimal(18,2) ,
@netpay decimal(18,2)

as

insert into tbl_payroll (emp_id,emp_name,monthly_rate,dDate,xBonus,xOT,SSS,PH,InTax,Others,absences,advances,tad,td,netpay) values 
(@emp_id,@emp_name,@monthly_rate,@dDate,@xBonus,@xOT,@SSS,@PH,@InTax,@Others,@absences,@advances,@tad,@td,@netpay)


---View Payroll Default---
create procedure View_Payroll_All
as
select * from tbl_Payroll

---View Payroll By Date---
create procedure View_Payroll_All
@date datetime
as
select * from tbl_Payroll
where ddate = @date










create procedure datess
@ddate datetime,
@date datetime
as
select * from tbl_timelog
where date_log between @ddate and @date




				
			insert_payroll 11,'992',123,'2016-09-06',3131123,13423,123,123,123,123,123,123,123,123,123
			
			create procedure sp_ID
			as
			declare @id int
			select @id = ident_current('tbl_emp')
			return @id
			
			
			
			
			
			
			
			drop proc checks
			create proc checks
			@date datetime,
			@id int
			as
			declare @r int
			select @r = count(*) from tbl_payroll
			where  dDAte = @date and emp_id = @id
			return @r
			
			drop proc check_in_am
			create proc check_in_am
			@date datetime,
			@id int
			as
			declare @r int
			select @r = count(*) from tbl_timelog
			where date_log=@date and id = @id 
			return @r
			
			create proc check_out_am
			@date datetime,
			@id int,
			@time varchar(50)
			as
			declare @r int
			select @r = count(*) from tbl_timelog
			where date_log=@date and id = @id and out_am = @time
			return @r
			
			create proc check_in_pm
			@date datetime,
			@id int,
			@time varchar(50)
			as
			declare @r int
			select @r = count(*) from tbl_timelog
			where date_log=@date and id = @id and in_pm = @time
			return @r
			
			create proc check_out_pm
			@date datetime,
			@id int,
			@time varchar(50)
			as
			declare @r int
			select @r = count(*) from tbl_timelog
			where date_log=@date and id = @id and out_pm = @time
			return @r
			
			create proc add_in_am
			@in_am varchar(50),
			@id int,
			@date datetime
			as
			insert into tbl_timelog(id,date_log,in_am) values (@id,@date,@in_am)
			
			drop proc add_out_am
			create proc add_out_am
			@out_am varchar(50),
			@id int,
			@date datetime
			as
			update tbl_timelog
			set out_am = @out_am
			where id = @id and date_log = @date
			
			drop proc add_in_pm
			create proc add_in_pm
			@in_pm varchar(50),
			@id int,
			@date datetime
			as
			update tbl_timelog
			set in_pm = @in_pm
			where id = @id and date_log = @date
			
			create proc add_out_pm
			@out_pm varchar(50),
			@id int,
			@date datetime
			as
			update tbl_timelog
			set out_pm = @out_pm
			where id = @id and date_log = @date
			
			create proc CheckAM_out
			@date datetime,
			@time varchar(50),
			@id int
			as
			declare @r int
			select @r = count(*) from tbl_timelog
			where date_log = @date and in_am = @time and id = @id
			
			drop proc add_in_am
			create proc add_in_am
			@id int,
			@name varchar(50),
			@date datetime,
			@in_am varchar(50),
			@out_am varchar(50),
			@total_am varchar(50),
			@in_pm varchar(50),
			@out_pm varchar(50),
			@total_pm varchar(50),
			@grand_total varchar(50)
			
			as
			insert into tbl_timelog(id,emp_name,date_log,in_am,out_am,total_am,in_pm,out_pm,total_pm,grand_total) values (@id,@name,@date,@in_am, @out_am,@total_am,@in_pm,@out_pm,@total_pm,@grand_total)
			
			add_out_am NULL,10,'2016-09-06'
			
			
			select * from tbl_timelog
			
			delete  from tbl_timelog
			delete from tbl_emp
			
			select * from tbl_payroll
			
			
			create proc total_am
		 @total_am varchar(50),
			@emp_name varchar(50),
			@date datetime,
			@id int
			as
			update tbl_timelog
			set total_am = @total_am
			where id = @id and date_log = @date
			checks '2016-09-06',11
			
			add_payroll 10,'ricard',123123,'2016-09-06',234,234,234,234,234,234,234,5234,534,900,4999
			
			
				select * from tbl_timelog
				
				select * from tbl_emp