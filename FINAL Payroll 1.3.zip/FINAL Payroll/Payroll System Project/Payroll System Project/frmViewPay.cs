﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmViewPay : Form
    {
        public frmViewPay()
        {
            InitializeComponent();
        }

        private void frmViewPay_Load(object sender, EventArgs e)
        {
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Dispose();
            frmMain main = new frmMain();
            main.Show();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string date = dateTimePicker1.Value.ToString().Substring(0, 10);
            dataGridView1.DataSource = clsPayroll.viewpay_date(DateTime.Parse(date));
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                btnPrintAll.Enabled = false;
                btnPrintSelected.Enabled = true;
            }
            if (dataGridView1.SelectedRows.Count > 1)
            {
                btnPrintAll.Enabled = true;
                btnPrintSelected.Enabled = false;
            }

        }

        private void btnPrintAll_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Reports r = new Reports();
                PayrollReport payrpt = new PayrollReport();
                var rs = dataGridView1.DataSource;
                payrpt.SetDataSource(rs);

                r.crystalReportViewer1.ReportSource = payrpt;
                r.Show();
            }

        }

        private void btnPrintSelected_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                clsPayroll clspay = new clsPayroll();
                Reports r = new Reports();
                PayrollReport payrpt = new PayrollReport();

                var rs = clspay.print_PaySelected(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                payrpt.SetDataSource(rs);

                r.crystalReportViewer1.ReportSource = payrpt;
                r.Show();
            }

        }
    }
}
