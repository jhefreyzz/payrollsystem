﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Payroll_System
{
    public partial class Reports : Form
    {
        public Reports()
        {
            InitializeComponent();
        }
    }
}
