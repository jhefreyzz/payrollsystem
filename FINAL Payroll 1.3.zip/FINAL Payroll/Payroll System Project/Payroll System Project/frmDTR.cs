﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;
using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace Payroll_System
{
    public partial class frmDTR : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public frmDTR()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt") ;
            lblDate.Text = DateTime.Today.DayOfWeek.ToString() + ", "+ DateTime.Today.ToString("M") + ", " + DateTime.Today.Year.ToString();
        }

        private void frmDTR_Load(object sender, EventArgs e)
        {
            timer1.Start();
            employPhoto.SizeMode = PictureBoxSizeMode.StretchImage;
        }

      
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmSelect frm = new frmSelect();
            frm.Show();
        }

      

      
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if(txtID.Text.Length != 0)
            {
                clsPayroll cls = new clsPayroll();
                var db = new DataClasses1DataContext();
               tbl_Employee t = null;
                
                t = db.tbl_Employees.SingleOrDefault(p => p.EMP_ID == txtID.Text);
                string date = DateTime.Now.ToString().Substring(0, 10);
                int verifyAM = cls.Verify_AM(DateTime.Parse(date.ToString()),txtID.Text);
                int verifyPM = cls.Verify_PM_IN(DateTime.Parse(date.ToString()), txtID.Text);
                string time = DateTime.Now.ToString("hh:mm:ss");
                tbl_TimeLog t1 = new tbl_TimeLog();



                if (t != null)
                {

                    employPhoto.Image = cls.byteArrayToImage(t.Emp_Photo.ToArray());
                    txtName.Text = t.Emp_Name;
                    txtDepartment.Text = t.Department;
                    txtPosition.Text = t.Position;
                    t1.Emp_Name = txtName.Text;
                    t1.EMP_ID = txtID.Text;
                    t1.Date = DateTime.Parse(date);
                    if (DateTime.Now.ToString("tt") == "AM")
                    {
                        if (verifyAM == 0)
                        {
                            t1.In_AM = time;
                            clsPayroll.Insert_AM(t1);
                            MessageBox.Show("Successfully Time-IN for morning!");
                            
                        }
                        else
                        {
                            t1.Out_AM = time;
                            clsPayroll.Insert_AM_Out(t1);
                            DialogResult res = MessageBox.Show("Successfully Time-OUT for morning!");

                            if (res == DialogResult.OK)
                            {
                                clsPayroll.Insert_TOTAL_AM(t1);
                            }
                            
                        }
                    }
                    else
                    {

                        if (verifyPM == 0)
                        {
                            t1.In_PM = time;
                            clsPayroll.Insert_IN_PM(t1);
                            MessageBox.Show("Successfully Time-In for afternoon!");
                            
                        }
                        else 
                        {
                            t1.Out_PM = time;
                            clsPayroll.Insert_OUT_PM(t1);
                            DialogResult res = MessageBox.Show("Successfully Time-Out for afternoon!");
                            txtID.Text = string.Empty;
                            if (res == DialogResult.OK)
                            {
                                clsPayroll.Insert_TOTAL_PM(t1);
                                clsPayroll.Insert_Grand_Total(t1);
                            }
                           

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Employee ID not Found!");
                    Clear();
                   
                }
            }
        }
        public void Clear()
        {
            
            employPhoto.Image = Payroll_System.Properties.Resources.placeholder;
            txtID.Clear();
            txtName.Clear();
            txtDepartment.Clear();
            txtPosition.Clear();
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
                textBox1_Validating(sender, new CancelEventArgs());
            
        }

        private void frmDTR_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0); 
        }

        private bool ValidateID()
        {
            bool valid = true;
            if (string.IsNullOrEmpty(txtID.Text))
            {
                errorProvider1.SetError(txtID, "Please insert your employee id");
                valid = false;
            }
            else
            {
                errorProvider1.SetError(txtID, "");
            }
                return valid;
            
               

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }

        private void txtID_MouseLeave(object sender, EventArgs e)
        {
            txtID.Clear();
        }
        

     

      

       
    }
}
