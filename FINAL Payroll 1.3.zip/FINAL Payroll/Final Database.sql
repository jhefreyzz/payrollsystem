-------DATABASE CREATION-------
create database Payroll_System
use payroll_system

-------START OF TABLE CREATIONS-------

---table Employee---
create table tbl_Employee
(
Emp_ID int primary key identity(1,1),
Emp_Name varchar(50) not null,
Gender varchar(20) not null,
[Status] varchar(20) not null,
[Address] varchar(100) not null,
Department varchar(50) not null,
Position varchar(50) not null,
Emp_Status varchar(50) not null,
Basic_Rate decimal(18,2) not null,
Date_Employed varchar(50) not null,
Emp_Photo varbinary(max) not null
)

---table Payroll---
create table tbl_Payroll
(
Trans_ID int primary key identity(1,1),
Emp_Id int not null foreign key references tbl_Employee(emp_id) on delete cascade,
Emp_Name varchar(50) not null,
Monthly_Rate decimal(18,2) not null,
Date datetime not null,
Bonus decimal(18,2) not null,
Overtime  decimal(18,2) not null,
SSS  decimal(18,2) not null,
PH  decimal(18,2) not null,
InTax  decimal(18,2) not null,
Others  decimal(18,2) not null,
Absences  decimal(18,2) not null,
Advances decimal(18,2) not null,
TAD decimal(18,2) not null,
Total_Deductions decimal(18,2) not null,
Netpay decimal(18,2) not null,
)

---table User---
create table tbl_User
(
id int primary key identity(1,1),
username varchar(50) not null,
[password] varchar(50) not null
)

---table TimeLog---
create table tbl_TimeLog
(
Log_Id int primary key identity(1,1),
Emp_Id int not null foreign key references tbl_Employee(emp_id) on delete cascade,
Emp_Name varchar(50) not null,
Date_Log datetime not null,
In_Am varchar(50),
Out_Am varchar(50),
Total_Am varchar(50),
In_Pm varchar(50),
Out_Pm varchar(50),
Total_Pm varchar(50),
Grand_Total varchar(50),
)

-------END OF TABLE CREATIONS-------


-------START OF STORED PROCEDURES-------

-----Stored Procedure for Table User-----
---Add Admin---
create procedure Add_Admin

@username varchar(50),
@password varchar(50)

as

insert into tbl_user (username,[password]) values(@username,@password)

-----Stored Procedures for Table Employee-----
---Auto Increment ID---
create procedure Disp_ID
as
declare @id int
select @id = ident_current('tbl_Employee')
return @id
---View Employee---
create procedure View_Employee

as

select * from tbl_Employee

---Add Employee---
create procedure Add_Employee
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50),
@emp_photo varbinary(max)

as

insert into tbl_employee(emp_name,gender,status,address,department,position,emp_status,basic_rate,date_employed,emp_photo) values (@emp_name,@gender,@status,@address,@dept,@position,@emp_stat,@basic_rate,@date_employed,@emp_photo)

---Delete Employee---
create procedure Del_Employee

@id int

as
delete from tbl_Employee
where emp_id = @id

---Update Employee---
create procedure Upd_Employee

@emp_id int,
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50)

as

update tbl_Employee
set emp_name =@emp_name,gender=@gender,[status]=@status,[address] = @address, department =@dept,position=@position,emp_status = @emp_stat,basic_rate=@basic_rate,date_employed = @date_employed
where emp_id = @emp_id

---Update Photo---
create procedure Upd_Photo

@emp_photo varbinary(max),
@id int

as
update tbl_Employee
set emp_photo = @emp_photo
where emp_id = @id


-----Stored Procedures for Table TimeLog-----
---View Timelog---
create procedure View_TimeLog
as
select * from tbl_timelog

---View TimeLog by Name---
create procedure View_TimeLog_Name

@emp_name varchar(max)
as

select * from tbl_Timelog
where emp_name like '%' + @emp_name

---View TimeLog by Date---
drop procedure View_TimeLog_date
create procedure View_TimeLog_Date
@startdate datetime,
@enddate datetime

as	

select * from tbl_Timelog
where date_log between @startdate and @enddate

---Insert TimeLog AM---
create procedure Insert_AM

@emp_name varchar(50),
@in_am varchar(50),
@id int,
@date_log datetime
as
insert into tbl_timelog (emp_name,in_am,date_log,emp_id) values (@emp_name,@in_am,@date_log,@id)

---Update TimeLog OUT AM---
create procedure  Insert_AM_Out
@out_am varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_am = @out_am
where emp_id = @id and date_log = @date

---Update TimeLog TOTAL AM---
create procedure  Insert_AM_TOTAL
@id int,
@date datetime
as
update tbl_timelog
set total_am =  CONVERT(VARCHAR(8), (CAST(out_am AS DATETIME) - CAST(in_am AS DATETIME)), 108)
where emp_id = @id and date_log = @date

---Update TimeLog IN PM---
create procedure Insert_PM_IN
@in_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set in_pm = @in_pm
where emp_id = @id and date_log = @date

---Update TimeLog OUT PM---
create procedure Insert_PM_Out
@out_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_pm = @out_pm
where emp_id = @id and date_log = @date


---Update TimeLog Total AM---
create procedure  Insert_PM_TOTAL
@id int,
@date datetime
as
update tbl_timelog
set total_pm =  CONVERT(VARCHAR(8), (CAST(out_pm AS DATETIME) - CAST(in_pm AS DATETIME)), 108)
where emp_id = @id and date_log = @date

---Update TimeLog Grand Total---
create procedure  Insert_GrandTotal
@id int,
@date datetime
as
update tbl_timelog
set grand_total =  CONVERT(VARCHAR(8), (CAST(total_am AS DATETIME) + CAST(total_pm AS DATETIME)), 108)
where emp_id = @id and date_log = @date

---CHECK IF DATA EXISTS BASED on ID and Current Date---
---Insert AM if no data exists---
create procedure Check_AM

@id int,
@date datetime

as

declare @checkdate int

select @checkdate = count(*) from tbl_timelog
where emp_id = @id and date_log = @date
return @checkdate

---If TimeLog for OUT AM exists---
create procedure Check_PM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(in_pm) from tbl_timelog
where emp_id = @id and date_log = @date
return @checkdate

-----Stored Procedures for Table Payroll-----
---Insert Payroll---
create procedure Add_Payroll
@emp_id int,
@emp_name varchar(50) ,
@monthly_rate decimal(18,2) ,
@dDate datetime ,
@xBonus decimal(18,2),
@xOT  decimal(18,2),
@SSS  decimal(18,2),
@PH  decimal(18,2) ,
@InTax  decimal(18,2),
@Others  decimal(18,2),
@absences  decimal(18,2),
@advances decimal(18,2),
@tad  decimal(18,2),
@td decimal(18,2) ,
@netpay decimal(18,2)

as

insert into tbl_payroll (emp_id,emp_name,monthly_rate,Date,Bonus,Overtime,SSS,PH,InTax,Others,absences,advances,tad,total_deductions,netpay) values 
(@emp_id,@emp_name,@monthly_rate,@dDate,@xBonus,@xOT,@SSS,@PH,@InTax,@Others,@absences,@advances,@tad,@td,@netpay)


---View Payroll Default---
create procedure View_Payroll_All
as
select * from tbl_Payroll

---View Payroll By Date---
create procedure View_Payroll_Date
@date datetime
as
select * from tbl_Payroll
where date = @date
		select * from tbl_user
---Verify Payroll Exists---
create procedure ViewExists
@emp_id int,
@dDate datetime
as
declare @viewcount int
select @viewcount = count(*) from tbl_Payroll
where emp_id = @emp_id and date = @ddate
return @viewcount
-------END OF STORED PROCEDURES-------

