-------DATABASE CREATION-------
create database Payroll_System
use payroll_system

-------START OF TABLE CREATIONS-------

---table Employee---
create table tbl_Emp
(
emp_id int primary key identity(1,1),
emp_Name varchar(50) not null,
gender varchar(20) not null,
status varchar(20) not null,
address varchar(100) not null,
dept varchar(50) not null,
position varchar(50) not null,
emp_stat varchar(50) not null,
basic_rate decimal(18,2) not null,
date_employed varchar(50) not null,
emp_photo varbinary(max) not null
)

---table Payroll---
create table tbl_payroll
(
Trans_ID int primary key identity(1,1),
emp_id int not null foreign key references tbl_Emp(emp_id) on delete cascade,
emp_name varchar(50) not null,
monthly_rate decimal(18,2) not null,
dDate datetime not null,
xBonus decimal(18,2) not null,
xOT  decimal(18,2) not null,
SSS  decimal(18,2) not null,
PH  decimal(18,2) not null,
InTax  decimal(18,2) not null,
Others  decimal(18,2) not null,
absences  decimal(18,2) not null,
advances decimal(18,2) not null,
tad  decimal(18,2) not null,
td decimal(18,2) not null,
netpay decimal(18,2) not null,
)

---table User---
drop table tbl_user
create table tbl_User
(
id int primary key identity(1,1),
username varchar(50) not null,
passwords varchar(50) not null
)

---table TimeLog---
drop table tbl_TimeLog
create table tbl_TimeLog
(
log_id int primary key identity(1,1),
emp_name varchar(50) not null,
date_log datetime not null,
in_am varchar(50),
out_am varchar(50),
total_am varchar(50),
in_pm varchar(50),
out_pm varchar(50),
total_pm varchar(50),
grand_total varchar(50),
id int not null foreign key references tbl_Emp(emp_id) on delete cascade
)

-------END OF TABLE CREATIONS-------


-------START OF STORED PROCEDURES-------

-----Stored Procedure for Table User-----
---Add Admin---
create procedure Add_Admin

@username varchar(50),
@password varchar(50)

as

insert into tbl_user (username,passwords) values(@username,@password)

-----Stored Procedures for Table Employee-----
---Auto Increment ID---
create procedure Disp_ID
as
declare @id int
select @id = ident_current('tbl_emp')
return @id
---View Employee---
create procedure View_Employee

as

select * from tbl_Emp

---Add Employee---
create procedure Add_Employee

@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50),
@emp_photo varbinary(max)

as

insert into tbl_emp (emp_name,gender,status,address,dept,position,emp_stat,basic_rate,date_employed,emp_photo) values (@emp_name,@gender,@status,@address,@dept,@position,@emp_stat,@basic_rate,@date_employed,@emp_photo)

---Delete Employee---
create procedure Del_Employee

@id int

as
delete from tbl_Emp
where emp_id = @id

---Update Employee---
create procedure Upd_Employee

@emp_id int,
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50)

as

update tbl_Emp
set emp_name =@emp_name,gender=@gender,status=@status,address = @address, dept =@dept,position=@position,emp_stat = @emp_stat,basic_rate=@basic_rate,date_employed = @date_employed
where emp_id = @emp_id

---Update Photo---
create procedure Upd_Photo

@emp_photo varbinary(max),
@id int

as
update tbl_Emp
set emp_photo = @emp_photo
where emp_id = @id


-----Stored Procedures for Table TimeLog-----
---View Timelog---
create procedure View_TimeLog
as
select * from tbl_timelog

---View TimeLog by Name---
create procedure View_TimeLog_Name

@emp_name varchar(50)
as

select * from tbl_Timelog
where emp_name like '%' + @emp_name

---View TimeLog by Date---
drop procedure View_TimeLog_date
create procedure View_TimeLog_Date
@startdate datetime,
@enddate datetime

as	

select * from tbl_Timelog
where date_log between @startdate and @enddate

---Insert TimeLog AM---
create procedure Insert_AM

@emp_name varchar(50),
@in_am varchar(50),
@id int,
@date_log datetime
as
insert into tbl_timelog (emp_name,in_am,date_log,id) values (@emp_name,@in_am,@date_log,@id)

---Update TimeLog OUT AM---
create procedure  Insert_AM_Out
@out_am varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_am = @out_am
where id = @id and date_log = @date

---Update TimeLog TOTAL AM---
create procedure  Insert_AM_TOTAL
@id int,
@date datetime
as
update tbl_timelog
set total_am =  CONVERT(VARCHAR(8), (CAST(out_am AS DATETIME) - CAST(in_am AS DATETIME)), 108)
where id = @id and date_log = @date

---Update TimeLog IN PM---
create procedure Insert_PM_IN
@in_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set in_pm = @in_pm
where id = @id and date_log = @date

---Update TimeLog OUT PM---
create procedure Insert_PM_Out
@out_pm varchar(50),
@id int,
@date datetime
as
update tbl_timelog
set out_pm = @out_pm
where id = @id and date_log = @date


---Update TimeLog Total AM---
create procedure  Insert_PM_TOTAL
@id int,
@date datetime
as
update tbl_timelog
set total_pm =  CONVERT(VARCHAR(8), (CAST(out_pm AS DATETIME) - CAST(in_pm AS DATETIME)), 108)
where id = @id and date_log = @date

---Update TimeLog Grand Total---
create procedure  Insert_GrandTotal
@id int,
@date datetime
as
update tbl_timelog
set grand_total =  CONVERT(VARCHAR(8), (CAST(total_am AS DATETIME) + CAST(total_pm AS DATETIME)), 108)
where id = @id and date_log = @date

---CHECK IF DATA EXISTS BASED on ID and Current Date---
---Insert AM if no data exists---
create procedure Check_AM

@id int,
@date datetime

as

declare @checkdate int

select @checkdate = count(*) from tbl_timelog
where id = @id and date_log = @date
return @checkdate

---If TimeLog for OUT AM exists---
create procedure Check_PM
@id int,
@date datetime

as 

declare @checkdate int
select @checkdate = count(in_pm) from tbl_timelog
where id = @id and date_log = @date
return @checkdate

-----Stored Procedures for Table Payroll-----
---Insert Payroll---
create procedure Add_Payroll
@emp_id int,
@emp_name varchar(50) ,
@monthly_rate decimal(18,2) ,
@dDate datetime ,
@xBonus decimal(18,2),
@xOT  decimal(18,2),
@SSS  decimal(18,2),
@PH  decimal(18,2) ,
@InTax  decimal(18,2),
@Others  decimal(18,2),
@absences  decimal(18,2),
@advances decimal(18,2),
@tad  decimal(18,2),
@td decimal(18,2) ,
@netpay decimal(18,2)

as

insert into tbl_payroll (emp_id,emp_name,monthly_rate,dDate,xBonus,xOT,SSS,PH,InTax,Others,absences,advances,tad,td,netpay) values 
(@emp_id,@emp_name,@monthly_rate,@dDate,@xBonus,@xOT,@SSS,@PH,@InTax,@Others,@absences,@advances,@tad,@td,@netpay)


---View Payroll Default---
create procedure View_Payroll_All
as
select * from tbl_Payroll

---View Payroll By Date---
create procedure View_Payroll_Date
@date datetime
as
select * from tbl_Payroll
where ddate = @date
		
---Verify Payroll Exists---
create procedure ViewExists
@emp_id int,
@dDate datetime
as
declare @viewcount int
select @viewcount = count(*) from tbl_Payroll
where emp_id = @emp_id and ddate = @ddate
return @viewcount
-------END OF STORED PROCEDURES-------

