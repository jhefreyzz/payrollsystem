﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{

    public partial class frmRegAdmin : Form
    {
        tbl_User u = new tbl_User();
       
        public frmRegAdmin()
        {
           
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            string encryptedpassword = cls.hashedPassword(txtPassword.Text);

            if (txtID.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Fill all fields");
            }
            else
            {
                u.username = txtID.Text;
                u.passwords = encryptedpassword;
                clsPayroll.Add(u);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmSelect select = new frmSelect();
            this.Hide();
            select.Show();
        }
    }
}
