﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;
using System.Runtime.InteropServices;

namespace Payroll_System
{
    public partial class frmAddEmploy : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public frmAddEmploy()
        {
            InitializeComponent();
        }

        private void frmAddEmploy_Load(object sender, EventArgs e)
        {
            tbl_Emp emp = new tbl_Emp();
            clsPayroll cls = new clsPayroll();
            int id = cls.ID() + 1;
            txtID.Text = id.ToString();
            txtName.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.tif;...";

            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox1.Image = new Bitmap(open.FileName);
            }
            
        }
      
        private void button2_Click(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            var image = cls.imageToByteArray(pictureBox1.Image);
            bool isNullOrEmpty = pictureBox1 == null || pictureBox1.Image == null;

            if (txtName.Text != ""   && txtPosition.Text != "" && txtDepartment.Text != "" && txtBasicRate.Text != "" && txtAddress.Text != "" && comboStatus.Text != "" && comboGender.Text != "" && comboEmployStatus.Text != "")
            {
                tbl_Emp emp = new tbl_Emp();
                emp.emp_Name = txtName.Text;
                emp.gender = comboGender.Text;
                emp.status = comboStatus.Text;
                emp.address = txtAddress.Text;
                emp.date_employed = dtpDateHired.Text;
                emp.position = txtPosition.Text;
                emp.dept = txtDepartment.Text;
                emp.basic_rate = decimal.Parse(txtBasicRate.Text);
                emp.emp_stat = comboEmployStatus.Text;
                emp.emp_photo = image;
                clsPayroll.Add_Emp(emp);
                MessageBox.Show("Successfully Added Employee!","ALERT",MessageBoxButtons.OK,MessageBoxIcon.Information);
                int id = cls.ID() + 1;
                txtID.Text = id.ToString();
                
                
                Clear();
                txtName.Focus();
            }
            else
            {
                MessageBox.Show("Make sure to fill all the fields","ALERT",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }
        public void Clear()
        {
            txtName.Clear();
            comboGender.ResetText();
            comboStatus.ResetText();
            txtAddress.Clear();
            dtpDateHired.ResetText();
            txtPosition.Clear();
            txtDepartment.Clear();
            txtBasicRate.Text = "0.00";
            comboEmployStatus.ResetText();
            txtName.Focus();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMain main = new frmMain();
            main.Show();
        }
        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

        
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            } 
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            pictureBox1.Image = Payroll_System.Properties.Resources.placeholder;
        }

        private void frmAddEmploy_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0); 
        }

       

       
    }
}
