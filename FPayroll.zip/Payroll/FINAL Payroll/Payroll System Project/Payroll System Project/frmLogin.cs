﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;
using System.Data.Linq;

namespace Payroll_System
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmSelect frm = new frmSelect();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtID.Text != "" || txtPassword.Text != "")
            {
                if (txtID.Text == "admin" && txtPassword.Text == "1234")
                {
                    MessageBox.Show("Welcome:\t" + txtID.Text);
                    frmMain main = new frmMain();
                    this.Hide();
                    main.Show();
                }
                else
                {
                    MessageBox.Show("Login Failed!");
                }
            }
            else
            {
                MessageBox.Show("Fill all fields");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            var db = new DataClasses1DataContext();
            tbl_User u = null;
            string encryptedpassword = cls.hashedPassword(txtPassword.Text);
            u = db.tbl_Users.FirstOrDefault(x => x.username == txtID.Text && x.passwords == encryptedpassword);
            if (txtID.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Fill all fields");
            }
            else
            {
                if (u != null)
                {
                    MessageBox.Show("Welcome:\t" + txtID.Text);
                    frmMain main = new frmMain();
                    main.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login Failed");
                    txtID.Clear();
                    txtPassword.Clear();
                    txtID.Focus();
                }
              
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frmSelect select = new frmSelect();
            select.Show();
        }
    }
}
