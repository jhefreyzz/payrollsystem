﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmSelect : Form
    {
        public frmSelect()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var db = new DataClasses1DataContext();
            var ts = db.tbl_Users.Count();

            if (ts == 1)
            {
                frmLogin login = new frmLogin();
                login.Show();
                this.Hide();
            }
            else
            {
                frmRegAdmin admin = new frmRegAdmin();
                admin.Show();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmDTR dtr = new frmDTR();
            dtr.Show();
            this.Hide();
        }

        private void frmSelect_Load(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
           
            tbl_Emp t = new tbl_Emp();
           
            
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            PrintDialog diag = new PrintDialog();
            diag.ShowDialog();
        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
