﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.Drawing;
namespace Payroll_Repositories
{
    public class clsPayroll
    {
        static DataClasses1DataContext db = null;

        public static void Add(tbl_User u)
        {
            db = new DataClasses1DataContext();
            db.Add_Admin(u.username, u.passwords);
        }

        public string hashedPassword(string password)
        {
            SHA1 algorithm = new SHA1CryptoServiceProvider();
            algorithm.ComputeHash(ASCIIEncoding.ASCII.GetBytes(password));
            byte[] ecryptedpassword = algorithm.Hash;
            StringBuilder sb = new StringBuilder();
            for (int ctr = 0; ctr < ecryptedpassword.Length; ctr++)
            {
                sb.Append(ecryptedpassword[ctr].ToString("x2"));
            }
            return sb.ToString();
        }
        public static void Add_Emp(tbl_Emp e)
        {
            db = new DataClasses1DataContext();

            db.Add_Employee(e.emp_Name, e.gender, e.status, e.address, e.dept, e.position, e.emp_stat, e.basic_rate, e.date_employed, e.emp_photo);
        }
        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
        public static void Upd_Emp(tbl_Emp e)
        {
            db = new DataClasses1DataContext();
            db.Upd_Employee(e.emp_id, e.emp_Name, e.gender, e.status, e.address, e.dept, e.position, e.emp_stat, e.basic_rate, e.date_employed);
        }
        public static List<View_EmployeeResult> view_Employee()
        {
            db = new DataClasses1DataContext();
            List<View_EmployeeResult> view = db.View_Employee().ToList<View_EmployeeResult>();
            return view;
        }
        public static void Del_Employee(tbl_Emp e)
        {
            db = new DataClasses1DataContext();
            db.Del_Employee(e.emp_id);

        }
        public static void Upd_EmpPhoto(tbl_Emp e)
        {
            db = new DataClasses1DataContext();
            db.Upd_Photo(e.emp_photo, e.emp_id);
        }
       
        public static List<View_TimeLogResult> view_time()
        {
            db = new DataClasses1DataContext();
            List<View_TimeLogResult> view_log = db.View_TimeLog().ToList<View_TimeLogResult>();
            return view_log;
        }    
        public static List<View_TimeLog_NameResult> View_TimeLogName(string name)
        {
            db = new DataClasses1DataContext();
            List<View_TimeLog_NameResult> timelog_name = db.View_TimeLog_Name(name).ToList<View_TimeLog_NameResult>();
            return timelog_name;
        }
        public static void Add_Pay(tbl_payroll p)
        {
            db = new DataClasses1DataContext();
            db.Add_Payroll(p.emp_id, p.emp_name, p.monthly_rate, p.dDate, p.xBonus, p.xOT, p.SSS, p.PH, p.InTax, p.Others, p.absences, p.advances, p.tad, p.td, p.netpay);

        }
        public static List<View_Payroll_AllResult> view_PayAll()
        {
            db = new DataClasses1DataContext();
            List<View_Payroll_AllResult> view_payall = db.View_Payroll_All().ToList<View_Payroll_AllResult>();
            return view_payall;
        }
        public int Verify_AM(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Check_AM(id,date));

        }
        public int Verify_PM_IN(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Check_PM(id, date));
        }
        public static void Insert_AM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM(t.emp_name, t.in_am, t.id, t.date_log);
        }
        public static void Insert_AM_Out(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM_Out(t.out_am,t.id,t.date_log);
        }
        public static void Insert_IN_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_IN(t.in_pm, t.id, t.date_log);
        }
        public static void Insert_OUT_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_Out(t.out_pm, t.id, t.date_log);
        }
        public static List<View_TimeLog_DateResult> viewTime_Date(DateTime start, DateTime end)
        {
            db = new DataClasses1DataContext();
            List<View_TimeLog_DateResult> Time_Date = db.View_TimeLog_Date(start, end).ToList<View_TimeLog_DateResult>();
            return Time_Date;
        }
        public static void Insert_TOTAL_AM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM_TOTAL(t.id, t.date_log);
        }
        public static void Insert_TOTAL_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_TOTAL(t.id, t.date_log);
        }
        public static void Insert_Grand_Total(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_GrandTotal(t.id, t.date_log);
        }
        public int CheckEntry(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.ViewExists(id, date));
        }
        public static List<View_Payroll_DateResult> viewpay_date(DateTime date)
        {
            db = new DataClasses1DataContext();
            List<View_Payroll_DateResult> viewpayDate = db.View_Payroll_Date(date).ToList<View_Payroll_DateResult>();
            return viewpayDate;
        }
        public int ID()
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Disp_ID());

        }
    }
}
