﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.Drawing;
namespace Payroll_Repositories
{
    public class clsPayroll
    {
        static DataClasses1DataContext db = null;

        public static void Add(tbl_User u)
        {
            db = new DataClasses1DataContext();
            db.Add_Admin(u.username, u.password);
        }

        public string hashedPassword(string password)
        {
            SHA1 algorithm = new SHA1CryptoServiceProvider();
            algorithm.ComputeHash(ASCIIEncoding.ASCII.GetBytes(password));
            byte[] ecryptedpassword = algorithm.Hash;
            StringBuilder sb = new StringBuilder();
            for (int ctr = 0; ctr < ecryptedpassword.Length; ctr++)
            {
                sb.Append(ecryptedpassword[ctr].ToString("x2"));
            }
            return sb.ToString();
        }
        public static void Add_Emp(tbl_Employee e)
        {
            db = new DataClasses1DataContext();
            db.Add_Employee(e.Emp_Name, e.Gender, e.Status, e.Address, e.Department, e.Position, e.Emp_Status, e.Basic_Rate, e.Date_Employed, e.Emp_Photo);
        }
        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
        public static void Upd_Emp(tbl_Employee e)
        {
            db = new DataClasses1DataContext();
            db.Upd_Employee(e.Emp_ID, e.Emp_Name, e.Gender, e.Status, e.Address, e.Department, e.Position, e.Emp_Status, e.Basic_Rate, e.Date_Employed);
        }
        public static List<View_EmployeeResult> view_Employee()
        {
            db = new DataClasses1DataContext();
            List<View_EmployeeResult> view = db.View_Employee().ToList<View_EmployeeResult>();
            return view;
        }
        public static void Del_Employee(tbl_Employee e)
        {
            db = new DataClasses1DataContext();
            db.Del_Employee(e.Emp_ID);

        }
        public static void Upd_EmpPhoto(tbl_Employee e)
        {
            db = new DataClasses1DataContext();
            db.Upd_Photo(e.Emp_Photo,e.Emp_ID);
        }
       
        public static List<View_TimeLogResult> view_time()
        {
            db = new DataClasses1DataContext();
            List<View_TimeLogResult> view_log = db.View_TimeLog().ToList<View_TimeLogResult>();
            return view_log;
        }    
        public static List<View_TimeLog_NameResult> View_TimeLogName(string name)
        {
            db = new DataClasses1DataContext();
            List<View_TimeLog_NameResult> timelog_name = db.View_TimeLog_Name(name).ToList<View_TimeLog_NameResult>();
            return timelog_name;
        }
        public static void Add_Pay(tbl_Payroll p)
        {
            db = new DataClasses1DataContext();
            db.Add_Payroll(p.Emp_Id, p.Emp_Name, p.Monthly_Rate, p.Date, p.Bonus, p.Overtime, p.SSS, p.PH, p.InTax, p.Others, p.Absences, p.Advances, p.TAD, p.Total_Deductions, p.Netpay);

        }
        public static List<View_Payroll_AllResult> view_PayAll()
        {
            db = new DataClasses1DataContext();
            List<View_Payroll_AllResult> view_payall = db.View_Payroll_All().ToList<View_Payroll_AllResult>();
            return view_payall;
        }
        public int Verify_AM(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Check_AM(id,date));

        }
        public int Verify_PM_IN(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Check_PM(id, date));
        }
        public static void Insert_AM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM(t.Emp_Name, t.In_Am, t.Emp_Id, t.Date_Log);
        }
        public static void Insert_AM_Out(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM_Out(t.Out_Am,t.Emp_Id,t.Date_Log);
        }
        public static void Insert_IN_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_IN(t.In_Pm, t.Emp_Id, t.Date_Log);
        }
        public static void Insert_OUT_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_Out(t.Out_Pm, t.Emp_Id, t.Date_Log);
        }
        public static List<View_TimeLog_DateResult> viewTime_Date(DateTime start, DateTime end)
        {
            db = new DataClasses1DataContext();
            List<View_TimeLog_DateResult> Time_Date = db.View_TimeLog_Date(start, end).ToList<View_TimeLog_DateResult>();
            return Time_Date;
        }
        public static void Insert_TOTAL_AM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_AM_TOTAL(t.Emp_Id, t.Date_Log);
        }
        public static void Insert_TOTAL_PM(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_PM_TOTAL(t.Emp_Id, t.Date_Log);
        }
        public static void Insert_Grand_Total(tbl_TimeLog t)
        {
            db = new DataClasses1DataContext();
            db.Insert_GrandTotal(t.Emp_Id, t.Date_Log);
        }
        public int CheckEntry(DateTime date, int id)
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.ViewExists(id, date));
        }
        public static List<View_Payroll_DateResult> viewpay_date(DateTime date)
        {
            db = new DataClasses1DataContext();
            List<View_Payroll_DateResult> viewpayDate = db.View_Payroll_Date(date).ToList<View_Payroll_DateResult>();
            return viewpayDate;
        }
        public int ID()
        {
            db = new DataClasses1DataContext();
            return Convert.ToInt32(db.Disp_ID());

        }
    }
}
