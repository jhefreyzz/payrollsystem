-------DATABASE CREATION-------
create database Payroll_System
use payroll_system

-------START OF TABLE CREATIONS-------

---table Employee---
truncate table tbl_Employee
drop table tbl_Employee
create table tbl_Employee
(
EMP_No int identity(1,1),
EMP_ID varchar(20)constraint pk_EmpID primary key ,
Emp_Name varchar(50) not null,
Gender varchar(20) not null,
[Status] varchar(20) not null,
[Address] varchar(100) not null,
[Department] varchar(50) not null,
Position varchar(50) not null,
Emp_Status varchar(50) not null,
Basic_Rate decimal(18,2) not null,
Date_Employed varchar(50) not null,
Emp_Photo varbinary(max) not null
)
select * from tbl_employee
---table Payroll---
drop table tbl_Payroll
create table tbl_Payroll
(
Trans_ID int primary key identity(1,1),
EMP_ID varchar(20) foreign key references tbl_employee(emp_id) on delete cascade,
Emp_Name varchar(50) not null,
Monthly_Rate decimal(18,2) not null,
[Date] datetime not null,
Bonus decimal(18,2) not null,
Overtime  decimal(18,2) not null,
SSS  decimal(18,2) not null,
PH  decimal(18,2) not null,
InTax  decimal(18,2) not null,
Others  decimal(18,2) not null,
Absences  decimal(18,2) not null,
Advances decimal(18,2) not null,
TAD  decimal(18,2) not null,
[Total Deductions] decimal(18,2) not null,
Netpay decimal(18,2) not null,
)

---table User---
drop table tbl_user
create table tbl_User
(
id int primary key identity(1,1),
username varchar(50) not null,
[password] varchar(50) not null
)

---table TimeLog---
drop table tbl_TimeLog
create table tbl_TimeLog
(
Log_id int primary key identity(1,1),
EMP_ID varchar(20) not null foreign key references tbl_employee(emp_Id) on delete cascade,
Emp_Name varchar(50) not null,
[Date] datetime not null,
In_AM varchar(50),
Out_AM varchar(50),
Total_AM varchar(50),
In_PM varchar(50),
Out_PM varchar(50),
Total_PM varchar(50),
Grand_Total varchar(50)
)

-------END OF TABLE CREATIONS-------


-------START OF STORED PROCEDURES-------

-----Stored Procedure for Table User-----
---Add Admin---
create procedure Add_Admin

@username varchar(50),
@password varchar(50)

as

insert into tbl_user (username,[password]) values(@username,@password)

-----Stored Procedures for Table Employee-----
---Auto Increment ID---
create procedure GetID
as
declare @id int
select @id = ident_current('tbl_employee')
return @id
---View Employee---
create procedure View_Employee

as

select EMP_ID,Emp_Name,Gender,[Status],[Address],Department,Position,Emp_Status,Basic_Rate,Date_Employed from tbl_Employee

---Add Employee---
create procedure Add_Employee
@emp_ID varchar(20),
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50),
@emp_photo varbinary(max)

as

insert into tbl_employee (EMP_ID,Emp_Name,Gender,[Status],[Address],Department,Position,Emp_Status,Basic_Rate,Date_Employed,Emp_Photo) values (@emp_ID,@emp_name,@gender,@status,@address,@dept,@position,@emp_stat,@basic_rate,@date_employed,@emp_photo)

---Delete Employee---
create procedure Del_Employee
@emp_ID varchar(max)

as
delete from tbl_Employee
where emp_id = @emp_id

---Update Employee---
create procedure Upd_Employee

@emp_id varchar(20),
@emp_Name varchar(50) ,
@gender varchar(20) ,
@status varchar(20),
@address varchar(100) ,
@dept varchar(50) ,
@position varchar(50) ,
@emp_stat varchar(50) ,
@basic_rate decimal(18,2),
@date_employed varchar(50)

as

update tbl_Employee
set Emp_Name =@emp_name,Gender=@gender,[Status]=@status,[Address] = @address, Department =@dept,Position=@position,Emp_Status = @emp_stat,Basic_Rate=@basic_rate,Date_Employed = @date_employed
where emp_id = @emp_id

---Update Photo---
create procedure Upd_Photo

@emp_photo varbinary(max),
@emp_ID varchar(20)

as
update tbl_Employee
set emp_photo = @emp_photo
where emp_id = @emp_id


-----Stored Procedures for Table TimeLog-----
---View Timelog---
create procedure View_TimeLog

as

select * from tbl_timelog

---View TimeLog by Name---
create procedure View_TimeLog_Name

@emp_name varchar(max)

as

select * from tbl_Timelog
where emp_name like '%' + @emp_name

---View TimeLog by Date---
drop procedure View_TimeLog_date
create procedure View_TimeLog_Date
@startdate datetime,
@enddate datetime

as	

select * from tbl_Timelog
where [Date] between @startdate and @enddate

---Insert TimeLog AM---
create procedure Insert_AM

@emp_name varchar(50),
@in_am varchar(50),
@emp_id varchar(20),
@date_log datetime
as
insert into tbl_timelog (emp_name,in_am,[date],emp_id) values (@emp_name,@in_am,@date_log,@emp_id)

---Update TimeLog OUT AM---
create procedure  Insert_AM_Out
@out_am varchar(50),
@emp_ID varchar(20),
@date datetime
as
update tbl_timelog
set out_am = @out_am
where emp_id = @emp_id and [date] = @date

---Update TimeLog TOTAL AM---
create procedure  Insert_AM_TOTAL
@emp_ID varchar(20),
@date datetime
as
update tbl_timelog
set total_am =  CONVERT(VARCHAR(8), (CAST(out_am AS DATETIME) - CAST(in_am AS DATETIME)), 108)
where emp_id = @emp_id and [date]= @date

---Update TimeLog IN PM---
create procedure Insert_PM_IN
@in_pm varchar(50),
@emp_id varchar(20),
@date datetime
as
update tbl_timelog
set in_pm = @in_pm
where emp_id = @emp_id and [date] = @date

---Update TimeLog OUT PM---
create procedure Insert_PM_Out
@out_pm varchar(50),
@emp_id varchar(20),
@date datetime
as
update tbl_timelog
set out_pm = @out_pm
where emp_id = @emp_id and [date] = @date


---Update TimeLog Total AM---
create procedure  Insert_PM_TOTAL
@emp_id varchar(20),
@date datetime
as
update tbl_timelog
set total_pm =  CONVERT(VARCHAR(8), (CAST(out_pm AS DATETIME) - CAST(in_pm AS DATETIME)), 108)
where emp_id = @emp_id and [date] = @date

---Update TimeLog Grand Total---
create procedure  Insert_GrandTotal
@emp_id varchar(20),
@date datetime
as
update tbl_timelog
set grand_total =  CONVERT(VARCHAR(8), (CAST(total_am AS DATETIME) + CAST(total_pm AS DATETIME)), 108)
where emp_id = @emp_id and [date] = @date

---CHECK IF DATA EXISTS BASED on ID and Current Date---
---Insert AM if no data exists---
create procedure Check_AM

@emp_id varchar(20),
@date datetime

as

declare @checkdate int

select @checkdate = count(*) from tbl_timelog
where emp_id = @emp_id and [date] = @date
return @checkdate

---If TimeLog for OUT AM exists---
create procedure Check_PM
@emp_id varchar(20),
@date datetime

as 

declare @checkdate int
select @checkdate = count(in_pm) from tbl_timelog
where emp_id = @emp_id and [date] = @date
return @checkdate

-----Stored Procedures for Table Payroll-----
---Insert Payroll---
create procedure Add_Payroll
@emp_id varchar(20),
@emp_name varchar(50) ,
@monthly_rate decimal(18,2) ,
@dDate datetime ,
@xBonus decimal(18,2),
@xOT  decimal(18,2),
@SSS  decimal(18,2),
@PH  decimal(18,2) ,
@InTax  decimal(18,2),
@Others  decimal(18,2),
@absences  decimal(18,2),
@advances decimal(18,2),
@tad  decimal(18,2),
@td decimal(18,2) ,
@netpay decimal(18,2)

as

insert into tbl_payroll (emp_id,emp_name,monthly_rate,[Date],Bonus,Overtime,SSS,PH,InTax,Others,absences,advances,tad,[total deductions],netpay) values 
(@emp_id,@emp_name,@monthly_rate,@dDate,@xBonus,@xOT,@SSS,@PH,@InTax,@Others,@absences,@advances,@tad,@td,@netpay)

select ident_current('tbl_employee')
SELECT isnull(IDENT_CURRENT('tbl_employee') + IDENT_INCR('tbl_employee'),1)
---View Payroll Default---
create procedure View_Payroll_All
as
select * from tbl_Payroll

---View Payroll By Date---
create procedure View_Payroll_Date
@date datetime
as
select * from tbl_Payroll
where [date] = @date
		
---Verify Payroll Exists---
create procedure ViewExists
@emp_id varchar(20),
@dDate datetime
as
declare @viewcount int
select @viewcount = count(*) from tbl_Payroll
where emp_id = @emp_id and [date] = @ddate
return @viewcount
---
create procedure view_Selected
@emp_id varchar(20)

as

select * from tbl_employee
where emp_id = @emp_id

---
create procedure pay_Selected
@emp_id varchar(20)

as

select * from tbl_Payroll
where emp_id = @emp_id
---
create procedure emp_Selected
@emp_id varchar(20)

as

select * from tbl_Employee
where emp_id = @emp_id
-------END OF STORED PROCEDURES-------

