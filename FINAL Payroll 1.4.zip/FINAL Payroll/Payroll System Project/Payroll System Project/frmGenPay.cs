﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace Payroll_System
{
    public partial class frmGenPay : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public frmGenPay()
        {
            InitializeComponent();
            CreateKeyPressEvent(this.Controls);
        }
        void CreateKeyPressEvent(System.Windows.Forms.Control.ControlCollection ctrls)
        {
            foreach (Control c in ctrls)
            {
                if (c is TextBox  )
                {
                    if (c.Name != txtNumDaysAbsent.Name)
                    
                        c.KeyPress += new KeyPressEventHandler(c_KeyPress);
                  
                }
                else
                    CreateKeyPressEvent(c.Controls);
            }
        }

        void c_KeyPress(object sender, KeyPressEventArgs e)
        {
          
          
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }


                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            
        }
        private void frmGenPay_Load(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
           
           this.ActiveControl = txtID;
            var db = new DataClasses1DataContext();
            dataGridView1.DataSource = clsPayroll.view_PayAll();
        
        }
      
     
        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            var db = new DataClasses1DataContext();
            tbl_Employee t = null;
           

            if (!string.IsNullOrEmpty(txtID.Text))
            {
              
                    t = db.tbl_Employees.SingleOrDefault(p => p.EMP_ID == txtID.Text);
                    if (t != null)
                    {
                        decimal basic_rate = decimal.Parse(t.Basic_Rate.ToString());
                        decimal month_rate = basic_rate * 30;

                        txtName.Text = t.Emp_Name;
                        txtDepartment.Text = t.Department;
                        txtBasicRate.Text = basic_rate.ToString();
                        txtMonthRate.Text = month_rate.ToString();
                        txtPosition.Text = t.Position;
                        txtEmployStatus.Text = t.Emp_Status;

                    }
                    else
                    {
                        MessageBox.Show("Employee ID not Found!");
                        Clear();
                        txtID.Focus();
                    }
                }

             
            
            
            
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox1_Validating(sender, new CancelEventArgs());
            }
        }

        private void Total_Deductions()
        {
            decimal deducts = 0;
            if (txtID.Text != string.Empty)
            {
                foreach (Control cont in this.groupBox4.Controls)
                {
                    if (cont.GetType().Name.ToString() == "TextBox")
                    {
                        if (cont.Name != "txtDeductions" && cont.Name != "txtNetPay" && string.IsNullOrEmpty(cont.Text) == false)
                        {

                            decimal d = decimal.Parse(cont.Text);
                            deducts += d;
                        }
                    }
                }

                txtDeductions.Text = deducts.ToString();

                txtNetPay.Text = (decimal.Parse(txtMonthRate.Text) - deducts).ToString();
            }
            else
            {
               
                txtID.Focus();
            }
          
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
              Total_Deductions();
        }
       
        private void textBox14_TextChanged(object sender, EventArgs e)
        {
           
            Total_Deductions();
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            
            Total_Deductions();
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
          
            Total_Deductions();
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {
            
            Total_Deductions();
        }
    

        private void button1_Click(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            string date = dtpPayDate.Value.ToString().Substring(0, 10);
           
            if (txtID.Text == string.Empty || txtAdvances.Text == string.Empty || txtBonus.Text == string.Empty || txtOT.Text == string.Empty || txtNumDaysAbsent.Text == string.Empty || txtSSS.Text == string.Empty || txtPH.Text == string.Empty || txtPagibig.Text == string.Empty || txtTax.Text == string.Empty || txtAbsences.Text == string.Empty )
            {
                MessageBox.Show("Must fill out all fields", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                int checker = cls.CheckEntry(DateTime.Parse(date), txtID.Text);

                if (checker == 0)
                {
                    tbl_Payroll pay = new tbl_Payroll();
                    pay.EMP_ID = txtID.Text;
                    pay.Emp_Name = txtName.Text;
                    pay.Monthly_Rate = decimal.Parse(txtMonthRate.Text);
                    pay.Date = DateTime.Parse(date.ToString());
                    pay.Bonus = decimal.Parse(txtBonus.Text);
                    pay.Overtime = decimal.Parse(txtOT.Text);
                    pay.SSS = decimal.Parse(txtSSS.Text);
                    pay.PH = decimal.Parse(txtPH.Text);
                    pay.InTax = decimal.Parse(txtTax.Text);
                    pay.Others = decimal.Parse(txtPagibig.Text);
                    pay.Absences = decimal.Parse(txtAbsences.Text);
                    pay.Advances = decimal.Parse(txtAdvances.Text);
                    pay.TAD = decimal.Parse(txtNumDaysAbsent.Text);
                    pay.Total_Deductions = decimal.Parse(txtDeductions.Text);
                    pay.Netpay = decimal.Parse(txtNetPay.Text);
                    clsPayroll.Add_Pay(pay);
                    MessageBox.Show("Successfully Generated Payroll!");
                    Clear();
                    //txtID.Text = pay.EMP_ID.ToString();
                    dataGridView1.DataSource = clsPayroll.view_PayAll();
                }
                else
                {
                    MessageBox.Show("Can't generate Payroll!. Payroll data exists!", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    txtID.Focus();
                }
            }
            
        }

        private void Clear()
        {
            txtID.Text = "";
            txtName.Clear();
            txtPosition.Clear();
            txtMonthRate.Clear();
            txtDepartment.Clear();
            txtBasicRate.Clear();
            txtEmployStatus.Clear();
            txtAdvances.Clear();
            txtBonus.Clear();
            txtOT.Clear();
            txtNumDaysAbsent.Clear();
            txtSSS.Clear();
            txtPH.Clear();
            txtTax.Clear();
            txtAbsences.Clear();
            txtPagibig.Clear();
            txtNetPay.Clear();
            txtDeductions.Clear();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            frmMain main = new frmMain();
            main.Show();
            this.Dispose();
        }

        private void frmGenPay_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0); 
        }

        private void txtNumDaysAbsent_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }
        }

       

      
   
    }
}
