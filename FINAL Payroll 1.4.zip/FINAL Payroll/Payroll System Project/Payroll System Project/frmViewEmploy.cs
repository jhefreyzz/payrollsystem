﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmViewEmploy : Form
    {
        public frmViewEmploy()
        {
            InitializeComponent();
        }

        private void frmViewEmploy_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = clsPayroll.view_Employee();
            btnPrintAll.Enabled = false;
            btnPrintSelected.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            dataGridView1.ClearSelection();
        }

        private void button5_Click(object sender, EventArgs e)
        {
          
            frmMain main = new frmMain();
            main.Show();
            this.Dispose();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            clsPayroll cls = new clsPayroll();
            tbl_Employee emp = new tbl_Employee();
            frmUpdateEmp updemp = new frmUpdateEmp();
          
            updemp.txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            updemp.txtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            updemp.comboGender.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            updemp.comboStatus.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            updemp.txtAddress.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            updemp.txtDepartment.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            updemp.txtPosition.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            updemp.comboEmployment.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            updemp.txtBasicRate.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            updemp.dtpDateHired.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            updemp.Show();
            this.Hide();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {


            
            tbl_Employee emp = new tbl_Employee();
            emp.EMP_ID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            clsPayroll.Del_Employee(emp);
            dataGridView1.DataSource = clsPayroll.view_Employee();


           

            
        }

       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.CurrentRow.Cells[2].Value =  toolStripMenuItem1.Text;
        }

      

     

        private void button4_Click(object sender, EventArgs e)
        {
            employeeReport rpt = new employeeReport();
            clsPayroll clspay = new clsPayroll();
           
            var rs = clspay.print_Selected(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            
        

            
            rpt.SetDataSource(rs);
            Reports r = new Reports();

            r.crystalReportViewer1.ReportSource = rpt;
            r.Show();
           
        }

      
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                btnPrintSelected.Enabled = true;
                btnPrintAll.Enabled = false;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            if (dataGridView1.SelectedRows.Count > 1)
            {
                btnPrintAll.Enabled = true;
                btnPrintSelected.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            
            }
        }

        private void btnPrintAll_Click(object sender, EventArgs e)
        {
            employeeReport rpt = new employeeReport();

            var rs = clsPayroll.view_Employee();
            rpt.SetDataSource(rs);
            Reports r = new Reports();
            
            r.crystalReportViewer1.ReportSource = rpt;
            r.Show();

        }


      
       
    }
}
