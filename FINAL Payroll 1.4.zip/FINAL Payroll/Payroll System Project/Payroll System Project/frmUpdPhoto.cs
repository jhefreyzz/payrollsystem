﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;
using System.Text.RegularExpressions;

namespace Payroll_System
{
    public partial class frmUpdPhoto : Form
    {
        public frmUpdPhoto()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMain main = new frmMain();
            main.Show();
        }

        private void frmUpdPhoto_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Payroll_System.Properties.Resources.placeholder;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openimage = new OpenFileDialog();
            openimage.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.tif;...";

            if (openimage.ShowDialog() == DialogResult.OK)
            {
                var image = new Bitmap(openimage.FileName);
                pictureBox1.Image = image;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtID.Text))
            {
                MessageBox.Show("Insert first the employee's id before updating the photo!");
                txtID.Focus();

            }
            else
            {
            clsPayroll cls = new clsPayroll();
            var db = new DataClasses1DataContext();
            var image = cls.imageToByteArray(pictureBox1.Image);
            tbl_Employee emp = new tbl_Employee();
           
            emp.EMP_ID= txtID.Text;
            emp.Emp_Photo= image;
            clsPayroll.Upd_EmpPhoto(emp);
            MessageBox.Show("Successfully updated employee's photo!");
            txtID.Clear();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
           
           
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        
        {
         
            
            clsPayroll cls = new clsPayroll();
            var db = new DataClasses1DataContext();
            tbl_Employee t = null;
         
          

                    t = db.tbl_Employees.SingleOrDefault(p => p.EMP_ID == txtID.Text);
                    if (!string.IsNullOrEmpty(txtID.Text))
                    {
                        if (t != null)
                        {
                            var image = t.Emp_Photo.ToArray();
                            pictureBox1.Image = cls.byteArrayToImage(image);
                        }
                        else
                        {
                            MessageBox.Show("Employee ID not Found!");
                            pictureBox1.Image = Payroll_System.Properties.Resources.placeholder;
                        }

                    }
               
           
            
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox1_Validating(sender, new CancelEventArgs());
            }
           
        }
    }
}
