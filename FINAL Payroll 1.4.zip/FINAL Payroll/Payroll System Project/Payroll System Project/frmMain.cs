﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
         toolStripStatusLabel2.Text = "Time:" + " " + DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAddEmploy addemp = new frmAddEmploy();
            addemp.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmViewEmploy viewemp = new frmViewEmploy();
            viewemp.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmviewDTR viewdtr = new frmviewDTR();
            viewdtr.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmUpdPhoto updphoto = new frmUpdPhoto();
            updphoto.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
            frmLogin admlogin = new frmLogin();
            admlogin.Show();
        }

        private void toolStripButton13_Click(object sender, EventArgs e)
        {
            
            frmAddEmploy addemp = new frmAddEmploy();
            addemp.Show();
            this.Hide();
        }

        private void toolStripButton14_Click(object sender, EventArgs e)
        {
            frmViewEmploy viewemp = new frmViewEmploy();
            viewemp.Show();
            this.Hide();
        }

        private void toolStripButton15_Click(object sender, EventArgs e)
        {
            frmviewDTR viewDTR = new frmviewDTR();
            viewDTR.Show();
            this.Hide();
        }

        private void toolStripButton16_Click(object sender, EventArgs e)
        {
            frmUpdPhoto updphoto = new frmUpdPhoto();
            updphoto.Show();
            this.Hide();
        }

        private void toolStripButton17_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
            frmLogin login = new frmLogin();
            login.Show();
        }

        private void toolStripButton18_Click(object sender, EventArgs e)
        {
            frmViewPay viewpay = new frmViewPay();
            viewpay.Show();
            this.Hide();
        }

        private void toolStripButton19_Click(object sender, EventArgs e)
        {
            frmGenPay addpay = new frmGenPay();
            addpay.Show();
            this.Hide();
        }

       
    }
}
