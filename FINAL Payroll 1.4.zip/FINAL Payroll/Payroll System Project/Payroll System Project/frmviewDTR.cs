﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmviewDTR : Form
    {
        public frmviewDTR()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = clsPayroll.view_time();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
   
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMain main = new frmMain();
            main.Show();
        }

        private void frmviewDTR_Load(object sender, EventArgs e)
        {
            btnViewAll.Checked = true;
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            string start = dateTimePicker1.Value.ToString().Substring(0, 10);
            string end = dateTimePicker2.Value.ToString().Substring(0, 10);
           

           
            dataGridView1.DataSource = clsPayroll.viewTime_Date(DateTime.Parse(start),DateTime.Parse(end));
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (txtName.Text.Length == 0  || btnViewName.Checked == false)
            {
                //   dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
            }
            else
            {
                dataGridView1.DataSource = clsPayroll.View_TimeLogName(txtName.Text);
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
           
           
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtName_Validating(sender,new CancelEventArgs() );
            }
        }

       
    }
}
