﻿namespace Payroll_System
{
    partial class frmGenPay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPayInfo = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblMonthRate = new System.Windows.Forms.Label();
            this.lblEmployStatus = new System.Windows.Forms.Label();
            this.lblDept = new System.Windows.Forms.Label();
            this.lblEmployPosition = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtBasicRate = new System.Windows.Forms.TextBox();
            this.txtMonthRate = new System.Windows.Forms.TextBox();
            this.txtEmployStatus = new System.Windows.Forms.TextBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpPayDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtDeductions = new System.Windows.Forms.TextBox();
            this.txtNetPay = new System.Windows.Forms.TextBox();
            this.txtPagibig = new System.Windows.Forms.TextBox();
            this.txtAbsences = new System.Windows.Forms.TextBox();
            this.txtPH = new System.Windows.Forms.TextBox();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtSSS = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtNumDaysAbsent = new System.Windows.Forms.TextBox();
            this.txtOT = new System.Windows.Forms.TextBox();
            this.txtBonus = new System.Windows.Forms.TextBox();
            this.txtAdvances = new System.Windows.Forms.TextBox();
            this.lblAdvances = new System.Windows.Forms.Label();
            this.lblBonus = new System.Windows.Forms.Label();
            this.lblOTPay = new System.Windows.Forms.Label();
            this.lblNoDaysAbsent = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(797, 74);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(213, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Generate Payroll";
            // 
            // lblPayInfo
            // 
            this.lblPayInfo.AutoSize = true;
            this.lblPayInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayInfo.Location = new System.Drawing.Point(6, 23);
            this.lblPayInfo.Name = "lblPayInfo";
            this.lblPayInfo.Size = new System.Drawing.Size(248, 20);
            this.lblPayInfo.TabIndex = 1;
            this.lblPayInfo.Text = "Payroll Information for the date of:";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(21, 38);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(104, 20);
            this.lblID.TabIndex = 3;
            this.lblID.Text = "Employee ID:";
            // 
            // lblMonthRate
            // 
            this.lblMonthRate.AutoSize = true;
            this.lblMonthRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonthRate.Location = new System.Drawing.Point(300, 38);
            this.lblMonthRate.Name = "lblMonthRate";
            this.lblMonthRate.Size = new System.Drawing.Size(107, 20);
            this.lblMonthRate.TabIndex = 4;
            this.lblMonthRate.Text = "Monthly Rate:";
            // 
            // lblEmployStatus
            // 
            this.lblEmployStatus.AutoSize = true;
            this.lblEmployStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployStatus.Location = new System.Drawing.Point(424, 116);
            this.lblEmployStatus.Name = "lblEmployStatus";
            this.lblEmployStatus.Size = new System.Drawing.Size(134, 20);
            this.lblEmployStatus.TabIndex = 7;
            this.lblEmployStatus.Text = "Employee Status:";
            // 
            // lblDept
            // 
            this.lblDept.AutoSize = true;
            this.lblDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDept.Location = new System.Drawing.Point(21, 116);
            this.lblDept.Name = "lblDept";
            this.lblDept.Size = new System.Drawing.Size(126, 20);
            this.lblDept.TabIndex = 12;
            this.lblDept.Text = "Employee Dept: ";
            // 
            // lblEmployPosition
            // 
            this.lblEmployPosition.AutoSize = true;
            this.lblEmployPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployPosition.Location = new System.Drawing.Point(424, 77);
            this.lblEmployPosition.Name = "lblEmployPosition";
            this.lblEmployPosition.Size = new System.Drawing.Size(143, 20);
            this.lblEmployPosition.TabIndex = 13;
            this.lblEmployPosition.Text = "Employee Position:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(21, 77);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(129, 20);
            this.lblName.TabIndex = 16;
            this.lblName.Text = "Employee Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(547, 38);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 20);
            this.label18.TabIndex = 17;
            this.label18.Text = "Daily Rate:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPosition);
            this.groupBox1.Controls.Add(this.txtBasicRate);
            this.groupBox1.Controls.Add(this.txtMonthRate);
            this.groupBox1.Controls.Add(this.txtEmployStatus);
            this.groupBox1.Controls.Add(this.txtDepartment);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.txtID);
            this.groupBox1.Controls.Add(this.lblEmployPosition);
            this.groupBox1.Controls.Add(this.lblID);
            this.groupBox1.Controls.Add(this.lblDept);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.lblName);
            this.groupBox1.Controls.Add(this.lblMonthRate);
            this.groupBox1.Controls.Add(this.lblEmployStatus);
            this.groupBox1.Location = new System.Drawing.Point(12, 137);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(769, 148);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Information:";
            // 
            // txtPosition
            // 
            this.txtPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosition.Location = new System.Drawing.Point(573, 74);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.ReadOnly = true;
            this.txtPosition.Size = new System.Drawing.Size(182, 26);
            this.txtPosition.TabIndex = 24;
            // 
            // txtBasicRate
            // 
            this.txtBasicRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBasicRate.Location = new System.Drawing.Point(639, 35);
            this.txtBasicRate.Name = "txtBasicRate";
            this.txtBasicRate.ReadOnly = true;
            this.txtBasicRate.Size = new System.Drawing.Size(116, 26);
            this.txtBasicRate.TabIndex = 23;
            // 
            // txtMonthRate
            // 
            this.txtMonthRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonthRate.Location = new System.Drawing.Point(413, 35);
            this.txtMonthRate.Name = "txtMonthRate";
            this.txtMonthRate.ReadOnly = true;
            this.txtMonthRate.Size = new System.Drawing.Size(116, 26);
            this.txtMonthRate.TabIndex = 22;
            // 
            // txtEmployStatus
            // 
            this.txtEmployStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployStatus.Location = new System.Drawing.Point(573, 113);
            this.txtEmployStatus.Name = "txtEmployStatus";
            this.txtEmployStatus.ReadOnly = true;
            this.txtEmployStatus.Size = new System.Drawing.Size(182, 26);
            this.txtEmployStatus.TabIndex = 21;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(167, 113);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.ReadOnly = true;
            this.txtDepartment.Size = new System.Drawing.Size(250, 26);
            this.txtDepartment.TabIndex = 20;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(167, 74);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(250, 26);
            this.txtName.TabIndex = 19;
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(167, 35);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(111, 26);
            this.txtID.TabIndex = 1;
            this.txtID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.txtID.Validating += new System.ComponentModel.CancelEventHandler(this.textBox1_Validating);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpPayDate);
            this.groupBox2.Controls.Add(this.lblPayInfo);
            this.groupBox2.Location = new System.Drawing.Point(12, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(769, 55);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Payroll Information:";
            // 
            // dtpPayDate
            // 
            this.dtpPayDate.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtpPayDate.Enabled = false;
            this.dtpPayDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPayDate.Location = new System.Drawing.Point(341, 17);
            this.dtpPayDate.Name = "dtpPayDate";
            this.dtpPayDate.Size = new System.Drawing.Size(383, 26);
            this.dtpPayDate.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtDeductions);
            this.groupBox4.Controls.Add(this.txtNetPay);
            this.groupBox4.Controls.Add(this.txtPagibig);
            this.groupBox4.Controls.Add(this.txtAbsences);
            this.groupBox4.Controls.Add(this.txtPH);
            this.groupBox4.Controls.Add(this.txtTax);
            this.groupBox4.Controls.Add(this.txtSSS);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Location = new System.Drawing.Point(316, 291);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(465, 142);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Deductions";
            // 
            // txtDeductions
            // 
            this.txtDeductions.BackColor = System.Drawing.Color.White;
            this.txtDeductions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeductions.Location = new System.Drawing.Point(353, 74);
            this.txtDeductions.Name = "txtDeductions";
            this.txtDeductions.ReadOnly = true;
            this.txtDeductions.Size = new System.Drawing.Size(99, 22);
            this.txtDeductions.TabIndex = 11;
            // 
            // txtNetPay
            // 
            this.txtNetPay.BackColor = System.Drawing.Color.White;
            this.txtNetPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNetPay.Location = new System.Drawing.Point(238, 104);
            this.txtNetPay.Name = "txtNetPay";
            this.txtNetPay.ReadOnly = true;
            this.txtNetPay.Size = new System.Drawing.Size(213, 29);
            this.txtNetPay.TabIndex = 12;
            // 
            // txtPagibig
            // 
            this.txtPagibig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPagibig.Location = new System.Drawing.Point(124, 74);
            this.txtPagibig.Name = "txtPagibig";
            this.txtPagibig.Size = new System.Drawing.Size(99, 22);
            this.txtPagibig.TabIndex = 8;
            this.txtPagibig.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // txtAbsences
            // 
            this.txtAbsences.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAbsences.Location = new System.Drawing.Point(352, 44);
            this.txtAbsences.Name = "txtAbsences";
            this.txtAbsences.Size = new System.Drawing.Size(99, 22);
            this.txtAbsences.TabIndex = 10;
            this.txtAbsences.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // txtPH
            // 
            this.txtPH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPH.Location = new System.Drawing.Point(126, 44);
            this.txtPH.Name = "txtPH";
            this.txtPH.Size = new System.Drawing.Size(99, 22);
            this.txtPH.TabIndex = 7;
            this.txtPH.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // txtTax
            // 
            this.txtTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTax.Location = new System.Drawing.Point(353, 10);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(99, 22);
            this.txtTax.TabIndex = 9;
            this.txtTax.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // txtSSS
            // 
            this.txtSSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSS.Location = new System.Drawing.Point(126, 10);
            this.txtSSS.Name = "txtSSS";
            this.txtSSS.Size = new System.Drawing.Size(99, 22);
            this.txtSSS.TabIndex = 6;
            this.txtSSS.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(143, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 24);
            this.label16.TabIndex = 15;
            this.label16.Text = "Net Pay:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 16);
            this.label11.TabIndex = 10;
            this.label11.Text = "SSS Contribution:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(235, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 16);
            this.label23.TabIndex = 19;
            this.label23.Text = "Witholding TAX:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(10, 50);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 16);
            this.label21.TabIndex = 9;
            this.label21.Text = "PH Contribution:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(233, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 16);
            this.label20.TabIndex = 19;
            this.label20.Text = "Absences:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Pag-ibig:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(233, 80);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 16);
            this.label22.TabIndex = 15;
            this.label22.Text = "Total Deductions:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtNumDaysAbsent);
            this.groupBox3.Controls.Add(this.txtOT);
            this.groupBox3.Controls.Add(this.txtBonus);
            this.groupBox3.Controls.Add(this.txtAdvances);
            this.groupBox3.Controls.Add(this.lblAdvances);
            this.groupBox3.Controls.Add(this.lblBonus);
            this.groupBox3.Controls.Add(this.lblOTPay);
            this.groupBox3.Controls.Add(this.lblNoDaysAbsent);
            this.groupBox3.Location = new System.Drawing.Point(12, 290);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(293, 143);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Data Entry";
            // 
            // txtNumDaysAbsent
            // 
            this.txtNumDaysAbsent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDaysAbsent.Location = new System.Drawing.Point(162, 105);
            this.txtNumDaysAbsent.Name = "txtNumDaysAbsent";
            this.txtNumDaysAbsent.Size = new System.Drawing.Size(125, 22);
            this.txtNumDaysAbsent.TabIndex = 5;
            this.txtNumDaysAbsent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumDaysAbsent_KeyPress);
            // 
            // txtOT
            // 
            this.txtOT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOT.Location = new System.Drawing.Point(162, 75);
            this.txtOT.Name = "txtOT";
            this.txtOT.Size = new System.Drawing.Size(125, 22);
            this.txtOT.TabIndex = 4;
            // 
            // txtBonus
            // 
            this.txtBonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBonus.Location = new System.Drawing.Point(162, 45);
            this.txtBonus.Name = "txtBonus";
            this.txtBonus.Size = new System.Drawing.Size(125, 22);
            this.txtBonus.TabIndex = 3;
            // 
            // txtAdvances
            // 
            this.txtAdvances.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdvances.Location = new System.Drawing.Point(162, 13);
            this.txtAdvances.Name = "txtAdvances";
            this.txtAdvances.Size = new System.Drawing.Size(125, 22);
            this.txtAdvances.TabIndex = 2;
            // 
            // lblAdvances
            // 
            this.lblAdvances.AutoSize = true;
            this.lblAdvances.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdvances.Location = new System.Drawing.Point(6, 19);
            this.lblAdvances.Name = "lblAdvances";
            this.lblAdvances.Size = new System.Drawing.Size(72, 16);
            this.lblAdvances.TabIndex = 11;
            this.lblAdvances.Text = "Advances:";
            // 
            // lblBonus
            // 
            this.lblBonus.AutoSize = true;
            this.lblBonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBonus.Location = new System.Drawing.Point(8, 48);
            this.lblBonus.Name = "lblBonus";
            this.lblBonus.Size = new System.Drawing.Size(49, 16);
            this.lblBonus.TabIndex = 8;
            this.lblBonus.Text = "Bonus:";
            // 
            // lblOTPay
            // 
            this.lblOTPay.AutoSize = true;
            this.lblOTPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOTPay.Location = new System.Drawing.Point(6, 78);
            this.lblOTPay.Name = "lblOTPay";
            this.lblOTPay.Size = new System.Drawing.Size(92, 16);
            this.lblOTPay.TabIndex = 5;
            this.lblOTPay.Text = "Overtime Pay:";
            // 
            // lblNoDaysAbsent
            // 
            this.lblNoDaysAbsent.AutoSize = true;
            this.lblNoDaysAbsent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoDaysAbsent.Location = new System.Drawing.Point(4, 108);
            this.lblNoDaysAbsent.Name = "lblNoDaysAbsent";
            this.lblNoDaysAbsent.Size = new System.Drawing.Size(126, 16);
            this.lblNoDaysAbsent.TabIndex = 6;
            this.lblNoDaysAbsent.Text = "No. of Days Absent:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridView1);
            this.groupBox5.Location = new System.Drawing.Point(12, 439);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(769, 218);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Payslip Information:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(763, 199);
            this.dataGridView1.TabIndex = 66;
            this.dataGridView1.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(504, 663);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(606, 663);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 14;
            this.btnPrint.Text = "Print Payslip";
            this.btnPrint.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(703, 663);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 15;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmGenPay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(797, 705);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "frmGenPay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmGenPay";
            this.Load += new System.EventHandler(this.frmGenPay_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmGenPay_MouseDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPayInfo;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblMonthRate;
        private System.Windows.Forms.Label lblEmployStatus;
        private System.Windows.Forms.Label lblDept;
        private System.Windows.Forms.Label lblEmployPosition;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtMonthRate;
        private System.Windows.Forms.TextBox txtEmployStatus;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dtpPayDate;
        private System.Windows.Forms.TextBox txtBasicRate;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtDeductions;
        private System.Windows.Forms.TextBox txtNetPay;
        private System.Windows.Forms.TextBox txtPagibig;
        private System.Windows.Forms.TextBox txtAbsences;
        private System.Windows.Forms.TextBox txtPH;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.TextBox txtSSS;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtNumDaysAbsent;
        private System.Windows.Forms.TextBox txtOT;
        private System.Windows.Forms.TextBox txtBonus;
        private System.Windows.Forms.TextBox txtAdvances;
        private System.Windows.Forms.Label lblAdvances;
        private System.Windows.Forms.Label lblBonus;
        private System.Windows.Forms.Label lblOTPay;
        private System.Windows.Forms.Label lblNoDaysAbsent;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnClose;
    }
}