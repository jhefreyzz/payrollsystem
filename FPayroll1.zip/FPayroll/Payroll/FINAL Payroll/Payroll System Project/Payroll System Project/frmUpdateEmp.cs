﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Payroll_Repositories;

namespace Payroll_System
{
    public partial class frmUpdateEmp : Form
    {
        public frmUpdateEmp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmViewEmploy emp = new frmViewEmploy();
            emp.Show();
            this.Dispose();
           
        }
        private void Clear()
        {
            txtID.Clear();
            txtName.Clear();
            comboGender.ResetText();
            comboStatus.ResetText();
            txtAddress.Clear();
            txtDepartment.Clear();
            txtPosition.Clear();
            comboEmployment.ResetText();
            txtBasicRate.Clear();
            dtpDateHired.ResetText();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtID.Text);
            tbl_Employee emp = new tbl_Employee();
            emp.Emp_ID = id;
            emp.Emp_Name = txtName.Text;
            emp.Gender = comboGender.Text;
            emp.Status = comboStatus.Text;
            emp.Address = txtAddress.Text;
            emp.Department = txtDepartment.Text;
            emp.Position = txtPosition.Text;
            emp.Emp_Status = comboEmployment.Text;
            emp.Basic_Rate = decimal.Parse(txtBasicRate.Text);
            emp.Date_Employed = dtpDateHired.Text;
            clsPayroll.Upd_Emp(emp);
            MessageBox.Show("Succesfully Updated Employee ID:" + id);
            Clear();

            
            
        }

        private void comboGender_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboStatus_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboEmployment_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtBasicRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
        && !char.IsDigit(e.KeyChar)
        && e.KeyChar != '.')
            {
                e.Handled = true;
            }

         
            if (e.KeyChar == '.'
                && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

    
    }
}
